# Mverechena dating app

Men bid for dates, women set a minimum price, and the money sits in Ecocash escrow until
the date is confirmed by a keyword. Flutter app + Firebase (Auth, Firestore, Storage,
Cloud Functions, Hosting) built with GitHub Actions.

Platform fee: **10% of the accepted bid, or $1 if 10% is less than $1** (taken from her payout;
he pays exactly what he bid). Change it in `lib/config.dart` and `functions/index.js`.

## How the flow works

| Step | Who | What happens |
|---|---|---|
| Sign up | user | username, phone, password, sex, 18+ box. Account is *pending*. |
| Activate | user + admin | User sends $1 to the Ecocash number with their username as reference and enters the transaction ID. Admin gets a push + sees it under **Activations**, taps **Activate**. |
| Touchline | all | Vertical scroll of approved photos/videos. Men: like, bid, report. Women: like, report, upload. |
| Bid | him | Short time / full time + amount. Below her minimum = auto-declined (he is told "too low", not her number). |
| Accept | her | Bids at/above her minimum show Accept / Reject. Accepting -> *waiting for confirmation*. |
| Escrow | him + admin | He sees the Ecocash number, exact amount and a reference code, pays, and enters the transaction ID. Admin gets a push, checks the money, taps **Funds received**. 24h to pay or the bid expires. |
| Details | her | *Confirmed*: she enters time, place and phone. He can now see them (and call / open the map). She is shown her keyword. |
| Keyword | him + admin | At the meet and greet she tells him the keyword; he types it into the app. Admin gets a push with the amount to pay her. |
| Payout | admin | Admin sends her Ecocash payout (bid minus fee), taps **Mark as paid**. |
| Problems | both | "Report a problem" freezes the money; admin resolves under **Disputes** (pay her or refund him). |

Phone numbers are kept in an admin-only document; each side only sees the other's number
after escrow is confirmed and she has shared it.

## One-time setup

1. **Firebase project**: create one in the console and upgrade to the **Blaze** plan (needed for
   Cloud Functions; the free usage tier still applies).
2. Enable **Authentication -> Email/Password** (usernames are turned into hidden `@mverechena.app` emails).
3. Create **Firestore** (production mode) and **Storage**.
4. Register a **Web app** and an **Android app** (package name `zw.co.mverechena.mverechena`).
   Copy the values into `lib/firebase_options.dart` (the Android values are inside `google-services.json`).
5. Push this folder to a GitHub repo. In **Settings -> Secrets and variables -> Actions** add
   `FIREBASE_SERVICE_ACCOUNT` (service-account JSON with *Firebase Admin* + *Cloud Functions Admin*)
   and `FIREBASE_PROJECT_ID`.
6. **Actions -> Deploy to Firebase -> Run workflow**: deploys functions, rules, indexes and the web admin site.
7. **Actions -> Build Mverechena**: download `mverechena-apk` from the run's artifacts and install it.
   (The workflow generates the `android/` and `web/` folders itself.)

## Making yourself the admin

1. Sign up in the app with your own username, then in the Firebase console open
   **Firestore -> users -> (your document)** and set `role` = `admin` and `status` = `active`.
2. Open the Android app (for push alerts) or the Hosting website (for a big-screen console).
   Log in as that user: you land on the admin console instead of the dating app.

## Running costs & limits to know about

- Escrow is manual: it is only as safe as you checking the Ecocash SMS before tapping **Funds received**.
  When volume grows, move to a Paynow/Ecocash merchant integration so payments confirm automatically.
- New uploads are hidden until you approve them (**Posts** tab). Check for under-18s and stolen photos.
- Reports from the touchline are saved in the `reports` collection (view in the Firebase console).
- To suspend someone, set `status` = `suspended` on their `users` document.
- You are responsible for complying with Zimbabwean law (Cyber and Data Protection Act, consumer
  and payment rules) and Ecocash terms for holding customer money.

## Project map

```
lib/main.dart                 auth gate + routing (pending / admin / man / woman)
lib/screens/feed_screen.dart  touchline + bid sheet + upload
lib/screens/bid_card.dart     bid card, escrow sheet, keyword, date details
lib/screens/dashboards.dart   his bids (3 tabs), her offers + minimum prices
lib/screens/admin_screen.dart admin console (5 tabs)
functions/index.js            all money and state changes
firestore.rules, storage.rules, firestore.indexes.json, firebase.json
.github/workflows/            build.yml (APK + web), deploy.yml (Firebase)
```
