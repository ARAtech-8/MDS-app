import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show kIsWeb;

/// Firebase project: mverechena-app.
/// These values are identifiers, not secrets, so they are safe to commit.
/// NOTE: the "web" block below reuses the Android app id. That is fine for the
/// phone app; to use the browser admin site, register a Web app in Firebase and
/// replace the web appId (and apiKey) with the ones it gives you.
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform => kIsWeb ? web : android;

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyBu5S_EI7hA2scRNpPom-ThL25fCA4jzXc',
    appId: '1:938181666033:android:2c51b40e082a48a4707550',
    messagingSenderId: '938181666033',
    projectId: 'mverechena-app',
    authDomain: 'mverechena-app.firebaseapp.com',
    storageBucket: 'mverechena-app.firebasestorage.app',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBu5S_EI7hA2scRNpPom-ThL25fCA4jzXc',
    appId: '1:938181666033:android:2c51b40e082a48a4707550',
    messagingSenderId: '938181666033',
    projectId: 'mverechena-app',
    storageBucket: 'mverechena-app.firebasestorage.app',
  );
}
