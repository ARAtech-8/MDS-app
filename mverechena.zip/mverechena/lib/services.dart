import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'config.dart';

final messengerKey = GlobalKey<ScaffoldMessengerState>();

void toast(String message) {
  messengerKey.currentState?.hideCurrentSnackBar();
  messengerKey.currentState?.showSnackBar(
    SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
  );
}

String errText(Object e) {
  if (e is String) return e;
  if (e is FirebaseAuthException) {
    switch (e.code) {
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'Wrong username or password.';
      case 'email-already-in-use':
        return 'That username is already taken.';
      case 'weak-password':
        return 'Password is too weak (use at least 6 characters).';
      case 'network-request-failed':
        return 'No internet connection.';
      case 'too-many-requests':
        return 'Too many attempts. Try again in a few minutes.';
      default:
        return e.message ?? 'Sign-in problem. Please try again.';
    }
  }
  return e.toString();
}

/// Runs [f], shows a toast on failure. Returns true when it succeeded.
Future<bool> guard(Future<void> Function() f) async {
  try {
    await f();
    return true;
  } catch (e) {
    toast(errText(e));
    return false;
  }
}

String emailFor(String username) =>
    '${username.trim().toLowerCase()}@${AppConfig.usernameDomain}';

/// Thin wrapper over Cloud Functions callables. All money-state changes go through here.
class Api {
  static final _fn =
      FirebaseFunctions.instanceFor(region: AppConfig.functionsRegion);

  static Future<Map<String, dynamic>> call(String name,
      [Map<String, dynamic>? data]) async {
    try {
      final res = await _fn.httpsCallable(name).call(data ?? {});
      final d = res.data;
      return d is Map ? Map<String, dynamic>.from(d) : <String, dynamic>{};
    } on FirebaseFunctionsException catch (e) {
      throw e.message ?? 'Something went wrong. Please try again.';
    }
  }
}

Future<void> openUrl(String url) async {
  final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  if (!ok) toast('Could not open that link.');
}

Future<void> callPhone(String phone) => openUrl('tel:$phone');

Future<void> openMaps(String query) => openUrl(
    'https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(query)}');

String bidCode(String id) => '#${id.substring(0, 6).toUpperCase()}';
