import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'firebase_options.dart';
import 'screens/activation_screen.dart';
import 'screens/admin_screen.dart';
import 'screens/auth_screen.dart';
import 'screens/home_shell.dart';
import 'services.dart';
import 'theme.dart';
import 'widgets.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MverechenaApp());
}

class MverechenaApp extends StatelessWidget {
  const MverechenaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mverechena',
      debugShowCheckedModeBanner: false,
      theme: Venus.theme,
      scaffoldMessengerKey: messengerKey,
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Splash();
        }
        final user = snap.data;
        if (user == null) return const AuthScreen();
        return UserGate(key: ValueKey(user.uid), user: user);
      },
    );
  }
}

/// Routes the signed-in user: not paid yet -> activation, admin -> admin panel,
/// otherwise the male/female app.
class UserGate extends StatefulWidget {
  final User user;
  const UserGate({super.key, required this.user});

  @override
  State<UserGate> createState() => _UserGateState();
}

class _UserGateState extends State<UserGate> {
  bool _pushStarted = false;

  Future<void> _initPush(String uid) async {
    if (kIsWeb) return; // push is for the Android app; web admin uses the in-app inbox
    try {
      final m = FirebaseMessaging.instance;
      await m.requestPermission();
      final token = await m.getToken();
      final ref = FirebaseFirestore.instance.doc('users/$uid');
      if (token != null) await ref.update({'fcmToken': token});
      m.onTokenRefresh.listen((t) => ref.update({'fcmToken': t}));
      FirebaseMessaging.onMessage.listen((msg) {
        final n = msg.notification;
        if (n != null) toast('${n.title ?? ''}\n${n.body ?? ''}'.trim());
      });
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final uid = widget.user.uid;
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.doc('users/$uid').snapshots(),
      builder: (context, snap) {
        if (snap.hasError) {
          return Scaffold(
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(errText(snap.error!), textAlign: TextAlign.center),
                    TextButton(onPressed: signOut, child: const Text('Sign out')),
                  ],
                ),
              ),
            ),
          );
        }
        if (!snap.hasData || !snap.data!.exists) {
          return const Splash(label: 'Setting up your account...');
        }
        final me = snap.data!.data()!;
        if (me['status'] == 'suspended') {
          return Scaffold(
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.block, size: 48, color: Venus.wine),
                    const SizedBox(height: 12),
                    const Text(
                      'This account has been suspended. Contact Mverechena support.',
                      textAlign: TextAlign.center,
                    ),
                    TextButton(onPressed: signOut, child: const Text('Sign out')),
                  ],
                ),
              ),
            ),
          );
        }
        if (me['status'] != 'active') {
          return ActivationScreen(uid: uid, me: me);
        }
        if (!_pushStarted) {
          _pushStarted = true;
          WidgetsBinding.instance.addPostFrameCallback((_) => _initPush(uid));
        }
        if (me['role'] == 'admin') return AdminScreen(uid: uid, me: me);
        return HomeShell(uid: uid, me: me);
      },
    );
  }
}
