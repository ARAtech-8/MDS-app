import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

import '../config.dart';
import '../logo.dart';
import '../services.dart';
import '../theme.dart';
import '../widgets.dart';

/// The "touchline": a TikTok-style vertical scroll of photos and short videos.
/// Men get a BID button; women do not (they can upload instead).
class FeedScreen extends StatefulWidget {
  final String uid;
  final Map<String, dynamic> me;
  const FeedScreen({super.key, required this.uid, required this.me});

  @override
  State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  final _page = PageController();
  bool _hot = false;
  int _index = 0;
  bool _uploading = false;
  late Stream<QuerySnapshot<Map<String, dynamic>>> _stream = _build();

  bool get isMale => widget.me['sex'] == 'male';

  Stream<QuerySnapshot<Map<String, dynamic>>> _build() => FirebaseFirestore
      .instance
      .collection('posts')
      .where('approved', isEqualTo: true)
      .orderBy(_hot ? 'bidCount' : 'createdAt', descending: true)
      .limit(60)
      .snapshots();

  void _setHot(bool hot) {
    if (hot == _hot) return;
    setState(() {
      _hot = hot;
      _index = 0;
      _stream = _build();
    });
    if (_page.hasClients) _page.jumpToPage(0);
  }

  Future<void> _upload() async {
    final picker = ImagePicker();
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo),
              title: const Text('Photo'),
              onTap: () => Navigator.pop(context, 'image'),
            ),
            ListTile(
              leading: const Icon(Icons.videocam),
              title: const Text('Short video (up to 30s)'),
              onTap: () => Navigator.pop(context, 'video'),
            ),
          ],
        ),
      ),
    );
    if (choice == null) return;
    final XFile? file = choice == 'video'
        ? await picker.pickVideo(
            source: ImageSource.gallery,
            maxDuration: const Duration(seconds: 30))
        : await picker.pickImage(
            source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
    if (file == null) return;
    if (!mounted) return;
    final caption = await _askCaption();
    if (caption == null) return;

    setState(() => _uploading = true);
    final ok = await guard(() async {
      final bytes = await file.readAsBytes();
      if (bytes.length > 50 * 1024 * 1024) {
        throw 'That file is too big (max 50MB).';
      }
      final ext = file.name.contains('.')
          ? file.name.split('.').last.toLowerCase()
          : (choice == 'video' ? 'mp4' : 'jpg');
      final contentType = choice == 'video'
          ? (ext == 'webm' ? 'video/webm' : ext == 'mov' ? 'video/quicktime' : 'video/mp4')
          : (ext == 'png' ? 'image/png' : 'image/jpeg');
      final path =
          'posts/${widget.uid}/${DateTime.now().millisecondsSinceEpoch}.$ext';
      final ref = FirebaseStorage.instance.ref(path);
      await ref.putData(bytes, SettableMetadata(contentType: contentType));
      final url = await ref.getDownloadURL();
      await FirebaseFirestore.instance.collection('posts').add({
        'ownerUid': widget.uid,
        'ownerName': widget.me['username'],
        'mediaUrl': url,
        'storagePath': path,
        'type': choice,
        'caption': caption,
        'approved': false,
        'likeCount': 0,
        'bidCount': 0,
        'createdAt': FieldValue.serverTimestamp(),
      });
    });
    if (ok) toast('Uploaded! It will appear on the touchline once approved.');
    if (mounted) setState(() => _uploading = false);
  }

  Future<String?> _askCaption() {
    final c = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Add a caption'),
        content: TextField(
          controller: c,
          maxLength: 120,
          decoration: const InputDecoration(hintText: 'Say something lovely'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          TextButton(
              onPressed: () => Navigator.pop(context, c.text.trim()),
              child: const Text('Upload')),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _page.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Venus.plum,
      body: Stack(
        children: [
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: _stream,
            builder: (context, snap) {
              if (snap.hasError) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(errText(snap.error!),
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Venus.pearl)),
                  ),
                );
              }
              if (!snap.hasData) {
                return const Center(
                    child: CircularProgressIndicator(color: Venus.rose));
              }
              final docs = snap.data!.docs;
              if (docs.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const VenusMarsLogo(size: 90),
                      const SizedBox(height: 12),
                      Text(
                        isMale
                            ? 'No profiles yet - check back soon.'
                            : 'Be the first on the touchline!\nTap the camera to upload.',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Venus.pearl),
                      ),
                    ],
                  ),
                );
              }
              return PageView.builder(
                controller: _page,
                scrollDirection: Axis.vertical,
                itemCount: docs.length,
                onPageChanged: (i) => setState(() => _index = i),
                itemBuilder: (_, i) => PostPage(
                  key: ValueKey(docs[i].id),
                  doc: docs[i],
                  active: i == _index,
                  isMale: isMale,
                  uid: widget.uid,
                ),
              );
            },
          ),
          // top bar
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: Row(
                children: [
                  const VenusMarsLogo(size: 36),
                  const Spacer(),
                  _Tab('New', !_hot, () => _setHot(false)),
                  const SizedBox(width: 6),
                  _Tab('Hot', _hot, () => _setHot(true)),
                  const Spacer(),
                  if (!isMale)
                    _uploading
                        ? const Padding(
                            padding: EdgeInsets.all(12),
                            child: SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2, color: Venus.rose)),
                          )
                        : IconButton(
                            icon: const Icon(Icons.add_a_photo,
                                color: Venus.pearl),
                            onPressed: _upload,
                          ),
                  NotificationsButton(uid: widget.uid, color: Venus.pearl),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Tab extends StatelessWidget {
  final String label;
  final bool on;
  final VoidCallback onTap;
  const _Tab(this.label, this.on, this.onTap);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: on ? Venus.rose.withValues(alpha: 0.9) : Colors.black26,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          label == 'Hot' ? 'Hot \u{1F525}' : label,
          style: TextStyle(
            color: on ? Venus.wine : Venus.pearl,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}

class PostPage extends StatefulWidget {
  final QueryDocumentSnapshot<Map<String, dynamic>> doc;
  final bool active;
  final bool isMale;
  final String uid;
  const PostPage({
    super.key,
    required this.doc,
    required this.active,
    required this.isMale,
    required this.uid,
  });

  @override
  State<PostPage> createState() => _PostPageState();
}

class _PostPageState extends State<PostPage> {
  VideoPlayerController? _vc;
  bool _ready = false;

  Map<String, dynamic> get d => widget.doc.data();

  @override
  void initState() {
    super.initState();
    if (d['type'] == 'video') {
      final c = VideoPlayerController.networkUrl(Uri.parse(d['mediaUrl']));
      _vc = c;
      c.setLooping(true);
      c.initialize().then((_) {
        if (!mounted) return;
        setState(() => _ready = true);
        if (widget.active) c.play();
      }).catchError((_) {});
    }
  }

  @override
  void didUpdateWidget(covariant PostPage old) {
    super.didUpdateWidget(old);
    if (_vc == null || !_ready) return;
    if (widget.active && !old.active) _vc!.play();
    if (!widget.active && old.active) _vc!.pause();
  }

  @override
  void dispose() {
    _vc?.dispose();
    super.dispose();
  }

  DocumentReference<Map<String, dynamic>> get _likeRef => FirebaseFirestore
      .instance
      .doc('posts/${widget.doc.id}/likes/${widget.uid}');

  Future<void> _toggleLike(bool liked) async {
    await guard(() async {
      if (liked) {
        await _likeRef.delete();
      } else {
        await _likeRef.set({'at': FieldValue.serverTimestamp()});
      }
    });
  }

  Future<void> _report() async {
    final reason = await showDialog<String>(
      context: context,
      builder: (_) => SimpleDialog(
        title: const Text('Report this post'),
        children: [
          for (final r in [
            'Not appropriate',
            'Fake or stolen photos',
            'Under 18',
            'Spam or scam',
          ])
            SimpleDialogOption(
                onPressed: () => Navigator.pop(context, r), child: Text(r)),
        ],
      ),
    );
    if (reason == null) return;
    final ok = await guard(() => FirebaseFirestore.instance
            .collection('reports')
            .add({
          'postId': widget.doc.id,
          'ownerUid': d['ownerUid'],
          'reporterUid': widget.uid,
          'reason': reason,
          'createdAt': FieldValue.serverTimestamp(),
        }));
    if (ok) toast('Thanks - our team will review it.');
  }

  Widget _media() {
    if (d['type'] == 'video') {
      if (!_ready || _vc == null) {
        return const Center(child: CircularProgressIndicator(color: Venus.rose));
      }
      return GestureDetector(
        onTap: () {
          if (_vc!.value.isPlaying) {
            _vc!.pause();
          } else {
            _vc!.play();
          }
          setState(() {});
        },
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _vc!.value.size.width,
            height: _vc!.value.size.height,
            child: VideoPlayer(_vc!),
          ),
        ),
      );
    }
    return Image.network(
      d['mediaUrl'],
      fit: BoxFit.cover,
      loadingBuilder: (c, child, p) => p == null
          ? child
          : const Center(child: CircularProgressIndicator(color: Venus.rose)),
      errorBuilder: (_, __, ___) => const Center(
          child: Icon(Icons.broken_image, color: Venus.rose, size: 48)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bids = (d['bidCount'] ?? 0) as int;
    final likes = (d['likeCount'] ?? 0) as int;
    final owner = (d['ownerName'] ?? '').toString();
    return Stack(
      fit: StackFit.expand,
      children: [
        _media(),
        // legibility gradient
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.transparent, Colors.transparent, Colors.black87],
              stops: [0, 0.55, 1],
            ),
          ),
        ),
        // right rail
        Positioned(
          right: 10,
          bottom: 24,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                stream: _likeRef.snapshots(),
                builder: (context, snap) {
                  final liked = snap.data?.exists ?? false;
                  return _RailButton(
                    icon: liked ? Icons.favorite : Icons.favorite_border,
                    color: liked ? Venus.rose : Colors.white,
                    label: '$likes',
                    onTap: () => _toggleLike(liked),
                  );
                },
              ),
              const SizedBox(height: 14),
              _RailButton(
                icon: Icons.local_fire_department,
                color: bids > 0 ? Colors.orangeAccent : Colors.white70,
                label: '$bids bids',
                onTap: () => toast(bids == 0
                    ? 'No bids yet - be the first!'
                    : '$bids ${bids == 1 ? 'man has' : 'men have'} bid for @$owner'),
              ),
              const SizedBox(height: 14),
              if (widget.isMale) ...[
                GestureDetector(
                  onTap: () => showBidSheet(context,
                      postId: widget.doc.id, ownerName: owner),
                  child: Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      gradient: Venus.gradient,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                            color: Venus.rose.withValues(alpha: 0.7),
                            blurRadius: 18)
                      ],
                    ),
                    child: const Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.gavel, color: Colors.white, size: 24),
                        Text('BID',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 12)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
              ],
              _RailButton(
                  icon: Icons.flag_outlined,
                  color: Colors.white70,
                  label: 'Report',
                  onTap: _report),
            ],
          ),
        ),
        // bottom-left info
        Positioned(
          left: 16,
          right: 90,
          bottom: 28,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('@$owner',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w800)),
              if ((d['caption'] ?? '').toString().isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(d['caption'],
                      style: const TextStyle(color: Colors.white)),
                ),
              if (bids >= 3)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.orange.withValues(alpha: 0.85),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Text('\u{1F525} In demand',
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w700)),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _RailButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final VoidCallback onTap;
  const _RailButton({
    required this.icon,
    required this.color,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 34),
          Text(label,
              style: const TextStyle(color: Colors.white, fontSize: 12)),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- bid sheet

Future<void> showBidSheet(
  BuildContext context, {
  required String postId,
  required String ownerName,
}) {
  return showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Venus.pearl,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
      child: _BidSheet(postId: postId, ownerName: ownerName),
    ),
  );
}

class _BidSheet extends StatefulWidget {
  final String postId;
  final String ownerName;
  const _BidSheet({required this.postId, required this.ownerName});

  @override
  State<_BidSheet> createState() => _BidSheetState();
}

class _BidSheetState extends State<_BidSheet> {
  String _type = 'short';
  final _amount = TextEditingController();
  bool _busy = false;

  Future<void> _submit() async {
    final amount = double.tryParse(_amount.text.trim());
    if (amount == null || amount < AppConfig.minBid) {
      toast('Minimum bid is \$${AppConfig.minBid.toStringAsFixed(2)}.');
      return;
    }
    setState(() => _busy = true);
    Map<String, dynamic>? res;
    final ok = await guard(() async {
      res = await Api.call('placeBid',
          {'postId': widget.postId, 'type': _type, 'amount': amount});
    });
    if (!mounted) return;
    setState(() => _busy = false);
    if (!ok) return;
    Navigator.pop(context);
    if (res?['status'] == 'auto_rejected') {
      toast('Bid not accepted - it was too low. Try a higher amount.');
    } else {
      toast('Bid sent to @${widget.ownerName}! Track it in My bids.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                      color: Venus.blush,
                      borderRadius: BorderRadius.circular(4))),
            ),
            const SizedBox(height: 14),
            Text('Bid for a date with @${widget.ownerName}',
                style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: Venus.wine)),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'short', label: Text('Short time')),
                  ButtonSegment(value: 'full', label: Text('Full time')),
                ],
                selected: {_type},
                onSelectionChanged: (s) => setState(() => _type = s.first),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              _type == 'short'
                  ? 'A short meet-up: coffee, lunch or a couple of hours.'
                  : 'A full date: a whole afternoon, evening or day out.',
              style: const TextStyle(fontSize: 12, color: Venus.copper),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _amount,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Your bid (USD)',
                prefixText: '\$ ',
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Nothing is charged yet. If she accepts, you pay into Ecocash '
              'escrow and she only gets paid after the meet and greet.',
              style: TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: VenusButton(
                  label: 'Place bid',
                  icon: Icons.gavel,
                  loading: _busy,
                  onPressed: _submit),
            ),
          ],
        ),
      ),
    );
  }
}
