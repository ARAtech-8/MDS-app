import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../logo.dart';
import '../services.dart';
import '../theme.dart';
import '../widgets.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs = TabController(length: 2, vsync: this);

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: Venus.bgGradient),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 16),
              const BrandHeader(logoSize: 110),
              const SizedBox(height: 12),
              TabBar(
                controller: _tabs,
                labelColor: Venus.pearl,
                unselectedLabelColor: Venus.rose,
                indicatorColor: Venus.copper,
                dividerColor: Colors.transparent,
                tabs: const [Tab(text: 'Sign in'), Tab(text: 'Sign up')],
              ),
              Expanded(
                child: Container(
                  margin: const EdgeInsets.only(top: 8),
                  decoration: const BoxDecoration(
                    color: Venus.pearl,
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(28)),
                  ),
                  child: TabBarView(
                    controller: _tabs,
                    children: const [_SignInForm(), _SignUpForm()],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SignInForm extends StatefulWidget {
  const _SignInForm();

  @override
  State<_SignInForm> createState() => _SignInFormState();
}

class _SignInFormState extends State<_SignInForm> {
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _busy = false;
  bool _hide = true;

  Future<void> _submit() async {
    if (_user.text.trim().isEmpty || _pass.text.isEmpty) {
      toast('Enter your username and password.');
      return;
    }
    setState(() => _busy = true);
    await guard(() => FirebaseAuth.instance.signInWithEmailAndPassword(
        email: emailFor(_user.text), password: _pass.text));
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        TextField(
          controller: _user,
          autocorrect: false,
          textInputAction: TextInputAction.next,
          decoration: const InputDecoration(
              labelText: 'Username', prefixIcon: Icon(Icons.person_outline)),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _pass,
          obscureText: _hide,
          onSubmitted: (_) => _submit(),
          decoration: InputDecoration(
            labelText: 'Password',
            prefixIcon: const Icon(Icons.lock_outline),
            suffixIcon: IconButton(
              icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
              onPressed: () => setState(() => _hide = !_hide),
            ),
          ),
        ),
        const SizedBox(height: 24),
        VenusButton(label: 'Sign in', loading: _busy, onPressed: _submit),
      ],
    );
  }
}

class _SignUpForm extends StatefulWidget {
  const _SignUpForm();

  @override
  State<_SignUpForm> createState() => _SignUpFormState();
}

class _SignUpFormState extends State<_SignUpForm> {
  final _user = TextEditingController();
  final _phone = TextEditingController();
  final _pass = TextEditingController();
  String _sex = 'male';
  bool _agree = false;
  bool _busy = false;
  bool _hide = true;

  Future<void> _submit() async {
    final username = _user.text.trim().toLowerCase();
    final phone = _phone.text.replaceAll(RegExp(r'[\s\-()]'), '');
    if (!RegExp(r'^[a-z0-9_]{3,20}$').hasMatch(username)) {
      toast('Username: 3-20 letters, numbers or underscore.');
      return;
    }
    if (!RegExp(r'^\+?[0-9]{9,14}$').hasMatch(phone)) {
      toast('Enter a valid phone number, e.g. 0771234567.');
      return;
    }
    if (_pass.text.length < 6) {
      toast('Password must be at least 6 characters.');
      return;
    }
    if (!_agree) {
      toast('Please confirm you are 18+ and accept the terms.');
      return;
    }
    setState(() => _busy = true);
    final auth = FirebaseAuth.instance;
    UserCredential? cred;
    try {
      cred = await auth.createUserWithEmailAndPassword(
          email: emailFor(username), password: _pass.text);
      await Api.call('registerUser', {
        'username': username,
        'phone': phone,
        'sex': _sex,
        'ageConfirmed': true,
      });
    } catch (e) {
      // roll back the auth account so the username is not left half-registered
      try {
        await cred?.user?.delete();
      } catch (_) {}
      toast(errText(e));
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(
                value: 'male', label: Text('Male'), icon: Icon(Icons.male)),
            ButtonSegment(
                value: 'female',
                label: Text('Female'),
                icon: Icon(Icons.female)),
          ],
          selected: {_sex},
          onSelectionChanged: (s) => setState(() => _sex = s.first),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _user,
          autocorrect: false,
          decoration: const InputDecoration(
              labelText: 'Username', prefixIcon: Icon(Icons.person_outline)),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _phone,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
              labelText: 'Phone number', prefixIcon: Icon(Icons.phone_outlined)),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _pass,
          obscureText: _hide,
          decoration: InputDecoration(
            labelText: 'Password',
            prefixIcon: const Icon(Icons.lock_outline),
            suffixIcon: IconButton(
              icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
              onPressed: () => setState(() => _hide = !_hide),
            ),
          ),
        ),
        const SizedBox(height: 8),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          controlAffinity: ListTileControlAffinity.leading,
          value: _agree,
          onChanged: (v) => setState(() => _agree = v ?? false),
          title: const Text(
            'I am 18 or older. Mverechena is for dating and companionship only; '
            'sexual services are not offered or permitted. I will meet in public places.',
            style: TextStyle(fontSize: 12),
          ),
        ),
        const SizedBox(height: 12),
        VenusButton(
            label: 'Create account', loading: _busy, onPressed: _submit),
        const SizedBox(height: 8),
        const Text(
          'A one-time \$1 activation fee is paid by Ecocash after sign up.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 12, color: Venus.copper),
        ),
      ],
    );
  }
}
