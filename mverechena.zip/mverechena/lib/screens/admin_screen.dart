import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../models.dart';
import '../services.dart';
import '../theme.dart';
import '../widgets.dart';

/// Admin console: activation payments, escrow confirmations, payouts after the
/// keyword arrives, disputes and photo/video approval. Works on web (Firebase
/// Hosting) and in the Android app (with push alerts).
class AdminScreen extends StatelessWidget {
  final String uid;
  final Map<String, dynamic> me;
  const AdminScreen({super.key, required this.uid, required this.me});

  @override
  Widget build(BuildContext context) {
    final db = FirebaseFirestore.instance;
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Mverechena admin'),
          actions: [
            NotificationsButton(uid: uid),
            IconButton(icon: const Icon(Icons.logout), onPressed: signOut),
          ],
          bottom: const TabBar(
            isScrollable: true,
            labelColor: Venus.pearl,
            unselectedLabelColor: Venus.rose,
            indicatorColor: Venus.copper,
            tabs: [
              Tab(text: 'Activations'),
              Tab(text: 'Escrow'),
              Tab(text: 'Payouts'),
              Tab(text: 'Disputes'),
              Tab(text: 'Posts'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _AdminList(
              query: db
                  .collection('users')
                  .where('status', isEqualTo: 'pending')
                  .orderBy('createdAt', descending: true),
              empty: 'No accounts waiting for activation.',
              builder: _userTile,
            ),
            _AdminList(
              query: db
                  .collection('bids')
                  .where('status', isEqualTo: 'escrow_submitted')
                  .orderBy('createdAt', descending: true),
              empty: 'No escrow payments to confirm.',
              builder: _escrowTile,
            ),
            _AdminList(
              query: db
                  .collection('bids')
                  .where('status', isEqualTo: 'completed')
                  .orderBy('createdAt', descending: true),
              empty: 'No payouts due.',
              builder: _payoutTile,
            ),
            _AdminList(
              query: db
                  .collection('bids')
                  .where('status', isEqualTo: 'disputed')
                  .orderBy('createdAt', descending: true),
              empty: 'No open disputes.',
              builder: _disputeTile,
            ),
            _AdminList(
              query: db
                  .collection('posts')
                  .where('approved', isEqualTo: false)
                  .orderBy('createdAt', descending: true),
              empty: 'No posts waiting for approval.',
              builder: _postTile,
            ),
          ],
        ),
      ),
    );
  }
}

class _AdminList extends StatelessWidget {
  final Query<Map<String, dynamic>> query;
  final String empty;
  final Widget Function(BuildContext, QueryDocumentSnapshot<Map<String, dynamic>>) builder;
  const _AdminList({required this.query, required this.empty, required this.builder});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: query.snapshots(),
      builder: (context, snap) {
        if (snap.hasError) {
          return Center(
              child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Text(errText(snap.error!), textAlign: TextAlign.center)));
        }
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snap.data!.docs;
        if (docs.isEmpty) {
          return Center(child: Text(empty, style: const TextStyle(color: Venus.copper)));
        }
        return ListView(
          padding: const EdgeInsets.all(10),
          children: [for (final d in docs) builder(context, d)],
        );
      },
    );
  }
}

Widget _shell(List<Widget> children) => Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
      ),
    );

Widget _title(String t) => Text(t,
    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Venus.wine));

Widget _info(String t) => Padding(
      padding: const EdgeInsets.only(top: 3),
      child: Text(t, style: const TextStyle(fontSize: 13)),
    );

Widget _phoneRow(String label, String phone) => Row(
      children: [
        Expanded(child: _info('$label: $phone')),
        IconButton(
            icon: const Icon(Icons.call, size: 20, color: Venus.emerald),
            onPressed: () => callPhone(phone)),
        IconButton(
            icon: const Icon(Icons.chat, size: 20, color: Venus.emerald),
            onPressed: () => openUrl('https://wa.me/${phone.replaceAll(RegExp(r'[^0-9]'), '')}')),
      ],
    );


/// Phones and dispute notes live in an admin-only document so the two sides of a
/// bid never see each other's numbers before escrow is confirmed.
Widget _withAdmin(String bidId, Widget Function(Map<String, dynamic> a) build) {
  return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
    stream: FirebaseFirestore.instance.doc('bids_admin/$bidId').snapshots(),
    builder: (context, snap) => build(snap.data?.data() ?? {}),
  );
}

Widget _actions(List<Widget> buttons) =>
    Padding(padding: const EdgeInsets.only(top: 10), child: Wrap(spacing: 8, runSpacing: 6, children: buttons));

Future<String?> _askText(BuildContext context, String title, {String hint = '', bool required = false}) {
  final c = TextEditingController();
  return showDialog<String>(
    context: context,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: TextField(controller: c, decoration: InputDecoration(hintText: hint)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        TextButton(
            onPressed: () {
              if (required && c.text.trim().isEmpty) return;
              Navigator.pop(context, c.text.trim());
            },
            child: const Text('OK')),
      ],
    ),
  );
}

// ------------------------------------------------------------------ tiles

Widget _userTile(BuildContext context, QueryDocumentSnapshot<Map<String, dynamic>> d) {
  final u = d.data();
  final txn = (u['activationTxn'] ?? '').toString();
  return _shell([
    _title('@${u['username']}  (${u['sex']})'),
    _phoneRow('Phone', '${u['phone']}'),
    _info('Reference to look for: ${'${u['username']}'.toUpperCase()}'),
    _info(txn.isEmpty ? 'No payment reference submitted yet.' : 'Ecocash txn ID: $txn'),
    _info('Signed up ${fmtTs(u['createdAt'])}'),
    _actions([
      ElevatedButton(
        onPressed: () => guard(() => Api.call('adminActivateUser', {'uid': d.id})),
        child: const Text('Activate'),
      ),
      if (txn.isNotEmpty)
        OutlinedButton(
          onPressed: () => guard(() => Api.call('adminRejectActivation', {'uid': d.id})),
          child: const Text('Reject payment'),
        ),
    ]),
  ]);
}

Widget _escrowTile(BuildContext context, QueryDocumentSnapshot<Map<String, dynamic>> d) {
  final b = d.data();
  return _shell([
    _title('${money((b['amount'] as num).toDouble())}  •  ${typeLabel('${b['type']}')}'),
    _info('Reference: ${bidCode(d.id)}   Txn ID: ${b['escrowTxn']}'),
    _info('Payer: @${b['maleName']}'),
    _withAdmin(d.id, (a) => _phoneRow('His phone', '${a['malePhone'] ?? ''}')),
    _info('Date with: @${b['femaleName']}'),
    _actions([
      ElevatedButton(
        onPressed: () => guard(() => Api.call('adminConfirmEscrow', {'bidId': d.id})),
        child: const Text('Funds received - confirm'),
      ),
      OutlinedButton(
        onPressed: () => guard(() => Api.call('adminRejectEscrow', {'bidId': d.id})),
        child: const Text('Not received'),
      ),
    ]),
  ]);
}

Widget _payoutTile(BuildContext context, QueryDocumentSnapshot<Map<String, dynamic>> d) {
  final b = d.data();
  final amount = (b['amount'] as num).toDouble();
  final fee = (b['fee'] as num).toDouble();
  final payout = (b['payout'] as num).toDouble();
  return _shell([
    _title('Pay ${money(payout)} to @${b['femaleName']}'),
    _info('Bid ${money(amount)} - platform fee ${money(fee)}   Ref ${bidCode(d.id)}'),
    _withAdmin(d.id, (a) => _phoneRow('Her Ecocash/phone', '${a['femalePhone'] ?? ''}')),
    _info('Keyword received ${fmtTs(b['completedAt'])} from @${b['maleName']}'),
    _actions([
      ElevatedButton(
        onPressed: () async {
          final ref = await _askText(context, 'Payout sent. Ecocash reference (optional)');
          if (ref == null) return;
          await guard(() => Api.call('adminMarkPaid', {'bidId': d.id, 'payoutTxn': ref}));
        },
        child: const Text('Mark as paid'),
      ),
    ]),
  ]);
}

Widget _disputeTile(BuildContext context, QueryDocumentSnapshot<Map<String, dynamic>> d) {
  final b = d.data();
  return _shell([
    _title('${money((b['amount'] as num).toDouble())}  •  ${bidCode(d.id)}'),
    _withAdmin(d.id, (a) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _info('Reported by ${a['disputedBy']}: ${a['disputeReason']}'),
            _info('Was at stage: ${a['prevStatus']}'),
            _phoneRow('His phone', '${a['malePhone'] ?? ''}'),
            _phoneRow('Her phone', '${a['femalePhone'] ?? ''}'),
          ],
        )),
    _actions([
      ElevatedButton(
        onPressed: () => guard(() =>
            Api.call('adminResolveDispute', {'bidId': d.id, 'outcome': 'payout'})),
        child: const Text('Pay her'),
      ),
      OutlinedButton(
        onPressed: () => guard(() =>
            Api.call('adminResolveDispute', {'bidId': d.id, 'outcome': 'refund'})),
        child: const Text('Refund him'),
      ),
    ]),
  ]);
}

Widget _postTile(BuildContext context, QueryDocumentSnapshot<Map<String, dynamic>> d) {
  final p = d.data();
  final isVideo = p['type'] == 'video';
  return _shell([
    _title('@${p['ownerName']}  (${isVideo ? 'video' : 'photo'})'),
    if (!isVideo)
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.network('${p['mediaUrl']}', height: 260, width: double.infinity, fit: BoxFit.cover),
        ),
      )
    else
      TextButton.icon(
        onPressed: () => openUrl('${p['mediaUrl']}'),
        icon: const Icon(Icons.play_circle),
        label: const Text('Open video'),
      ),
    if ('${p['caption'] ?? ''}'.isNotEmpty) _info('"${p['caption']}"'),
    _actions([
      ElevatedButton(
        onPressed: () => guard(() => Api.call('adminModeratePost', {'postId': d.id, 'action': 'approve'})),
        child: const Text('Approve'),
      ),
      OutlinedButton(
        onPressed: () => guard(() => Api.call('adminModeratePost', {'postId': d.id, 'action': 'remove'})),
        child: const Text('Remove'),
      ),
    ]),
  ]);
}
