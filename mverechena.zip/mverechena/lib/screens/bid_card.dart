import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../config.dart';
import '../models.dart';
import '../services.dart';
import '../theme.dart';
import '../widgets.dart';

/// One bid, shown to either side. The action area changes with the bid's status,
/// which is how the whole escrow flow stays simple for the user.
class BidCard extends StatelessWidget {
  final DocumentSnapshot<Map<String, dynamic>> doc;
  final bool isMale;
  final Map<String, dynamic> me;
  const BidCard({
    super.key,
    required this.doc,
    required this.isMale,
    required this.me,
  });

  Map<String, dynamic> get b => doc.data() ?? {};

  @override
  Widget build(BuildContext context) {
    final status = (b['status'] ?? '').toString();
    final (label, color) = statusInfo(status, isMale: isMale);
    final amount = (b['amount'] as num?)?.toDouble() ?? 0;
    final payout = (b['payout'] as num?)?.toDouble() ?? 0;
    final other = isMale ? '@${b['femaleName']}' : '@${b['maleName']}';
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(color: color.withValues(alpha: 0.35)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${typeLabel('${b['type']}')} • ${money(amount)}',
                    style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: Venus.wine),
                  ),
                ),
                StatusChip(label, color),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              '${isMale ? 'For' : 'From'} $other  •  ${bidCode(doc.id)}  •  ${fmtTs(b['createdAt'])}',
              style: const TextStyle(fontSize: 12, color: Colors.black54),
            ),
            if (!isMale && payout > 0)
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text(
                  'You receive ${money(payout)} (after the ${money(AppConfig.feeFor(amount))} platform fee)',
                  style: const TextStyle(fontSize: 12, color: Venus.emerald),
                ),
              ),
            const SizedBox(height: 8),
            isMale ? _maleActions(context, status) : _femaleActions(context, status),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ male

  Widget _maleActions(BuildContext context, String status) {
    switch (status) {
      case 'pending':
        return _row([
          OutlinedButton(
            onPressed: () => _confirmCancel(context),
            child: const Text('Cancel bid'),
          ),
        ]);
      case 'accepted':
        final dl = b['escrowDeadline'];
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'She accepted! Pay into escrow to lock the date.'
              '${dl is Timestamp ? ' Pay before ${fmtTs(dl)}.' : ''}',
            ),
            const SizedBox(height: 8),
            if (b['escrowRejected'] == true)
              const Padding(
                padding: EdgeInsets.only(bottom: 8),
                child: Text(
                  'Your last payment reference could not be verified. Please re-check it.',
                  style: TextStyle(color: Colors.redAccent, fontSize: 12),
                ),
              ),
            VenusButton(
              label: 'Ecocash escrow',
              icon: Icons.lock_outline,
              onPressed: () => showEscrowSheet(context, doc),
            ),
            TextButton(
              onPressed: () => _confirmCancel(context),
              child: const Text('Cancel bid'),
            ),
          ],
        );
      case 'escrow_submitted':
        return _note(Icons.hourglass_top,
            'Payment reference ${b['escrowTxn']} sent. Waiting for admin to confirm your funds in escrow.');
      case 'escrow_confirmed':
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _note(Icons.lock, 'Funds are safe in escrow. Waiting for her to send the time and place.'),
            _reportButton(context),
          ],
        );
      case 'details_shared':
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DetailsView(bidId: doc.id, showMapsButton: true),
            const SizedBox(height: 10),
            _KeywordBox(bidId: doc.id),
            _reportButton(context),
          ],
        );
      case 'completed':
        return _note(Icons.verified,
            'Keyword confirmed. Her payout is being released. Enjoy your date!');
      case 'paid':
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DetailsView(bidId: doc.id, showMapsButton: false),
            _note(Icons.check_circle, 'This date is complete.'),
          ],
        );
      case 'disputed':
        return _note(Icons.support_agent,
            'Mverechena support is reviewing this date. Funds stay frozen until it is resolved.');
      case 'auto_rejected':
        return _note(Icons.trending_up,
            'Her minimum was higher than your bid, so it was declined automatically. Try bidding again with a higher amount.');
      default:
        return const SizedBox.shrink();
    }
  }

  // ---------------------------------------------------------------- female

  Widget _femaleActions(BuildContext context, String status) {
    switch (status) {
      case 'pending':
        return _row([
          Expanded(
            child: OutlinedButton(
              onPressed: () => _respond(context, false),
              child: const Text('Reject'),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: ElevatedButton(
              onPressed: () => _respond(context, true),
              child: const Text('Accept'),
            ),
          ),
        ]);
      case 'accepted':
      case 'escrow_submitted':
        return _note(Icons.hourglass_top,
            'Waiting for confirmation that his payment is safe in escrow. We will notify you.');
      case 'escrow_confirmed':
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _note(Icons.check_circle,
                'Confirmed! The money is in escrow. Tell us when and where to meet.'),
            const SizedBox(height: 8),
            _DetailsForm(bidId: doc.id, phone: '${me['phone'] ?? ''}'),
            _reportButton(context),
          ],
        );
      case 'details_shared':
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _KeywordShow(bidId: doc.id, payout: (b['payout'] as num?)?.toDouble() ?? 0),
            const SizedBox(height: 8),
            DetailsView(bidId: doc.id, showMapsButton: false),
            _reportButton(context),
          ],
        );
      case 'completed':
        return _note(Icons.payments_outlined,
            'He sent the keyword. Your payout of ${money((b['payout'] as num?)?.toDouble() ?? 0)} is being sent to your Ecocash.');
      case 'paid':
        return _note(Icons.check_circle,
            'Paid ${money((b['payout'] as num?)?.toDouble() ?? 0)} to your Ecocash.');
      case 'disputed':
        return _note(Icons.support_agent,
            'Mverechena support is reviewing this date.');
      default:
        return const SizedBox.shrink();
    }
  }

  // --------------------------------------------------------------- helpers

  Widget _row(List<Widget> children) => Row(children: children);

  Widget _note(IconData icon, String text) => Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: Venus.copper),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 13))),
        ],
      );

  Widget _reportButton(BuildContext context) => TextButton.icon(
        onPressed: () => _report(context),
        icon: const Icon(Icons.flag_outlined, size: 16),
        label: const Text('Report a problem'),
      );

  Future<void> _respond(BuildContext context, bool accept) async {
    await guard(() => Api.call('respondBid', {'bidId': doc.id, 'accept': accept}));
  }

  Future<void> _confirmCancel(BuildContext context) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Cancel this bid?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('No')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Yes, cancel')),
        ],
      ),
    );
    if (yes == true) {
      await guard(() => Api.call('cancelBid', {'bidId': doc.id}));
    }
  }

  Future<void> _report(BuildContext context) async {
    final c = TextEditingController();
    final reason = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Report a problem'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
                'Funds stay frozen while support reviews. Tell us what happened.',
                style: TextStyle(fontSize: 13)),
            const SizedBox(height: 8),
            TextField(controller: c, maxLines: 3),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          TextButton(
              onPressed: () => Navigator.pop(context, c.text.trim()),
              child: const Text('Send')),
        ],
      ),
    );
    if (reason == null || reason.length < 3) return;
    final ok = await guard(
        () => Api.call('reportProblem', {'bidId': doc.id, 'reason': reason}));
    if (ok) toast('Reported. Support will contact you.');
  }
}

// ------------------------------------------------------------ escrow sheet

void showEscrowSheet(
    BuildContext context, DocumentSnapshot<Map<String, dynamic>> bid) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Venus.pearl,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
      child: _EscrowSheet(bid: bid),
    ),
  );
}

class _EscrowSheet extends StatefulWidget {
  final DocumentSnapshot<Map<String, dynamic>> bid;
  const _EscrowSheet({required this.bid});

  @override
  State<_EscrowSheet> createState() => _EscrowSheetState();
}

class _EscrowSheetState extends State<_EscrowSheet> {
  final _txn = TextEditingController();
  bool _busy = false;

  Future<void> _submit() async {
    final t = _txn.text.trim();
    if (t.length < 4) {
      toast('Enter the transaction ID from your Ecocash confirmation SMS.');
      return;
    }
    setState(() => _busy = true);
    final ok = await guard(() =>
        Api.call('submitEscrowTxn', {'bidId': widget.bid.id, 'txnId': t}));
    if (!mounted) return;
    setState(() => _busy = false);
    if (ok) {
      Navigator.pop(context);
      toast('Thanks! Admin has been notified and will confirm your escrow.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final amount = (widget.bid.data()?['amount'] as num?)?.toDouble() ?? 0;
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Ecocash escrow',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: Venus.wine)),
            const SizedBox(height: 6),
            const Text(
              'Your money is held in escrow and released to your date only when '
              'you enter the keyword she gives you at the meet and greet.',
              style: TextStyle(fontSize: 13),
            ),
            const SizedBox(height: 12),
            const Text('1. Send exactly this amount by Ecocash:',
                style: TextStyle(fontWeight: FontWeight.w700)),
            CopyRow('Amount', amount.toStringAsFixed(2)),
            CopyRow('Ecocash number', AppConfig.ecocashNumber),
            CopyRow('Reference (put this in your note)', bidCode(widget.bid.id)),
            const SizedBox(height: 10),
            const Text('2. Enter the transaction ID from the Ecocash SMS:',
                style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            TextField(
              controller: _txn,
              textCapitalization: TextCapitalization.characters,
              decoration:
                  const InputDecoration(labelText: 'Ecocash transaction ID'),
            ),
            const SizedBox(height: 8),
            const Text(
              '3. Admin confirms the funds. You then receive her time, place and phone number.',
              style: TextStyle(fontSize: 12, color: Venus.copper),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: VenusButton(
                  label: "I've paid - notify admin",
                  icon: Icons.send,
                  loading: _busy,
                  onPressed: _submit),
            ),
          ],
        ),
      ),
    );
  }
}

// -------------------------------------------------------- date details etc.

class DetailsView extends StatelessWidget {
  final String bidId;
  final bool showMapsButton;
  const DetailsView({super.key, required this.bidId, required this.showMapsButton});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.doc('bids/$bidId/details/info').snapshots(),
      builder: (context, snap) {
        final d = snap.data?.data();
        if (d == null) return const SizedBox.shrink();
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Venus.blush.withValues(alpha: 0.5),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _line(Icons.event, fmtTs(d['dateTime'], 'EEE d MMM yyyy, HH:mm')),
              _line(Icons.place, '${d['location']}'),
              _line(Icons.phone, '${d['phone']}'),
              Row(
                children: [
                  TextButton.icon(
                    onPressed: () => callPhone('${d['phone']}'),
                    icon: const Icon(Icons.call, size: 16),
                    label: const Text('Call'),
                  ),
                  if (showMapsButton)
                    TextButton.icon(
                      onPressed: () => openMaps('${d['location']}'),
                      icon: const Icon(Icons.map, size: 16),
                      label: const Text('Map'),
                    ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _line(IconData i, String t) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            Icon(i, size: 18, color: Venus.wine),
            const SizedBox(width: 8),
            Expanded(child: Text(t, style: const TextStyle(fontSize: 14))),
          ],
        ),
      );
}

/// Male: type the keyword received from his date at the meet and greet.
class _KeywordBox extends StatefulWidget {
  final String bidId;
  const _KeywordBox({required this.bidId});

  @override
  State<_KeywordBox> createState() => _KeywordBoxState();
}

class _KeywordBoxState extends State<_KeywordBox> {
  final _c = TextEditingController();
  bool _busy = false;

  Future<void> _send() async {
    if (_c.text.trim().length < 3) {
      toast('Enter the keyword your date gave you.');
      return;
    }
    setState(() => _busy = true);
    Map<String, dynamic>? res;
    final ok = await guard(() async {
      res = await Api.call(
          'submitKeyword', {'bidId': widget.bidId, 'keyword': _c.text});
    });
    if (!mounted) return;
    setState(() => _busy = false);
    if (!ok) return;
    if (res?['ok'] == true) {
      toast('Keyword confirmed. Admin will release her payment.');
    } else {
      toast('That keyword is not right. Attempts left: ${res?['attemptsLeft'] ?? 0}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'When you meet, ask for her keyword and enter it here. '
          'This releases your payment to her.',
          style: TextStyle(fontSize: 12, color: Venus.copper),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _c,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(
                    labelText: 'Keyword from your date', isDense: true),
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton(
              onPressed: _busy ? null : _send,
              child: _busy
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white))
                  : const Text('Send'),
            ),
          ],
        ),
      ],
    );
  }
}

/// Female: shows her secret keyword and what to do with it.
class _KeywordShow extends StatelessWidget {
  final String bidId;
  final double payout;
  const _KeywordShow({required this.bidId, required this.payout});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.doc('bids_private/$bidId').snapshots(),
      builder: (context, snap) {
        final k = snap.data?.data()?['keyword']?.toString();
        if (k == null) return const SizedBox.shrink();
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: Venus.gradient,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            children: [
              const Text('YOUR KEYWORD',
                  style: TextStyle(
                      color: Colors.white70, fontSize: 11, letterSpacing: 2)),
              const SizedBox(height: 4),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(k,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2)),
                  IconButton(
                    icon: const Icon(Icons.copy, color: Colors.white, size: 18),
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: k));
                      toast('Copied');
                    },
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                'Give this keyword to your date ONLY when you meet and you feel safe. '
                'When he sends it to Mverechena, your ${money(payout)} is paid to your Ecocash.',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 12),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// Female: time, location and phone number once funds are confirmed in escrow.
class _DetailsForm extends StatefulWidget {
  final String bidId;
  final String phone;
  const _DetailsForm({required this.bidId, required this.phone});

  @override
  State<_DetailsForm> createState() => _DetailsFormState();
}

class _DetailsFormState extends State<_DetailsForm> {
  late final _phone = TextEditingController(text: widget.phone);
  final _loc = TextEditingController();
  DateTime? _when;
  bool _busy = false;

  Future<void> _pick() async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: now.add(const Duration(days: 1)),
      firstDate: now,
      lastDate: now.add(const Duration(days: 60)),
    );
    if (d == null || !mounted) return;
    final t = await showTimePicker(
        context: context, initialTime: const TimeOfDay(hour: 15, minute: 0));
    if (t == null) return;
    setState(() => _when = DateTime(d.year, d.month, d.day, t.hour, t.minute));
  }

  Future<void> _submit() async {
    if (_when == null) {
      toast('Pick a date and time.');
      return;
    }
    if (_loc.text.trim().length < 3) {
      toast('Enter a meeting place (a public place is safest).');
      return;
    }
    if (_phone.text.trim().length < 7) {
      toast('Enter your phone number.');
      return;
    }
    setState(() => _busy = true);
    final ok = await guard(() => Api.call('submitDetails', {
          'bidId': widget.bidId,
          'dateTime': _when!.toUtc().toIso8601String(),
          'location': _loc.text.trim(),
          'phone': _phone.text.trim(),
        }));
    if (mounted) setState(() => _busy = false);
    if (ok) toast('Sent! Your keyword is now shown on this card.');
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        OutlinedButton.icon(
          onPressed: _pick,
          icon: const Icon(Icons.event),
          label: Text(_when == null
              ? 'Pick date & time'
              : fmtTs(Timestamp.fromDate(_when!), 'EEE d MMM, HH:mm')),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _loc,
          decoration: const InputDecoration(
              labelText: 'Meeting place (public place)',
              prefixIcon: Icon(Icons.place),
              isDense: true),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _phone,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
              labelText: 'Phone number to share',
              prefixIcon: Icon(Icons.phone),
              isDense: true),
        ),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: VenusButton(
              label: 'Send details & get keyword',
              loading: _busy,
              onPressed: _submit),
        ),
      ],
    );
  }
}
