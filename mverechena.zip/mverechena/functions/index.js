/**
 * Mverechena backend. Every money/state change goes through these callables so the
 * phone can never fake an escrow confirmation, a keyword match or a payout.
 *
 * Bid status flow:
 *   pending -> accepted -> escrow_submitted -> escrow_confirmed -> details_shared
 *           -> completed (keyword matched) -> paid
 *   side exits: auto_rejected, rejected, cancelled, expired, disputed -> refunded | completed
 */
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { onDocumentWritten } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();
const { FieldValue, Timestamp } = admin.firestore;

const REGION = "us-central1";
const opts = { region: REGION, cors: true };

// --- money rules (mirror lib/config.dart) ---
const MIN_BID = 2;
const FEE_RATE = 0.1;
const MIN_FEE = 1;
const ESCROW_WINDOW_HOURS = 24;
const PENDING_BID_DAYS = 7;
const MAX_KEYWORD_ATTEMPTS = 5;
const USERNAME_DOMAIN = "mverechena.app";

const r2 = (n) => Math.round(n * 100) / 100;
const feeFor = (amount) => Math.max(r2(amount * FEE_RATE), MIN_FEE);

// ------------------------------------------------------------------ helpers

function need(cond, code, msg) {
  if (!cond) throw new HttpsError(code, msg);
}

async function getUser(uid) {
  const snap = await db.doc(`users/${uid}`).get();
  need(snap.exists, "not-found", "Account not found.");
  return { id: uid, ...snap.data() };
}

async function activeUser(req) {
  need(req.auth, "unauthenticated", "Please sign in.");
  const u = await getUser(req.auth.uid);
  need(u.status === "active", "failed-precondition", "Your account is not active yet.");
  return u;
}

async function adminUser(req) {
  const u = await activeUser(req);
  need(u.role === "admin", "permission-denied", "Admins only.");
  return u;
}

async function getBid(bidId) {
  need(typeof bidId === "string" && bidId.length > 0, "invalid-argument", "Missing bid.");
  const ref = db.doc(`bids/${bidId}`);
  const snap = await ref.get();
  need(snap.exists, "not-found", "Bid not found.");
  return { ref, id: bidId, ...snap.data() };
}

const code = (id) => "#" + id.slice(0, 6).toUpperCase();
const money = (n) => "$" + Number(n).toFixed(2);

/** In-app inbox entry + push notification (push is best effort). */
async function notify(uid, title, body, data = {}) {
  try {
    await db.collection("notifications").add({
      uid, title, body, read: false, createdAt: FieldValue.serverTimestamp(),
    });
    const u = await db.doc(`users/${uid}`).get();
    const token = u.exists ? u.data().fcmToken : null;
    if (token) {
      await admin.messaging().send({
        token,
        notification: { title, body },
        data: Object.fromEntries(Object.entries(data).map(([k, v]) => [k, String(v)])),
        android: { priority: "high" },
      });
    }
  } catch (e) {
    console.warn("notify failed", uid, e.message);
  }
}

async function notifyAdmins(title, body, data = {}) {
  const admins = await db.collection("users").where("role", "==", "admin").get();
  await Promise.all(admins.docs.map((d) => notify(d.id, title, body, data)));
}

const WORDS = [
  "ROSE", "LOTUS", "PEARL", "AMBER", "COPPER", "JADE", "ORCHID", "SILK",
  "DAWN", "MANGO", "EMBER", "IVORY", "LILAC", "OPAL", "SUNRISE", "VELVET",
];
function makeKeyword() {
  const pick = () => WORDS[Math.floor(Math.random() * WORDS.length)];
  const num = String(Math.floor(10 + Math.random() * 90));
  return `${pick()}-${pick()}-${num}`;
}
const norm = (s) => String(s || "").toUpperCase().replace(/[^A-Z0-9]/g, "");

// ------------------------------------------------------- sign up & activation

exports.registerUser = onCall(opts, async (req) => {
  need(req.auth, "unauthenticated", "Please sign in.");
  const uid = req.auth.uid;
  const username = String(req.data.username || "").trim().toLowerCase();
  const phone = String(req.data.phone || "").replace(/[\s\-()]/g, "");
  const sex = req.data.sex;
  need(/^[a-z0-9_]{3,20}$/.test(username), "invalid-argument", "Invalid username.");
  need(/^\+?[0-9]{9,14}$/.test(phone), "invalid-argument", "Invalid phone number.");
  need(sex === "male" || sex === "female", "invalid-argument", "Choose male or female.");
  need(req.data.ageConfirmed === true, "failed-precondition", "You must confirm you are 18 or older.");
  need(
    req.auth.token.email === `${username}@${USERNAME_DOMAIN}`,
    "permission-denied", "Username does not match the account."
  );

  await db.runTransaction(async (tx) => {
    const userRef = db.doc(`users/${uid}`);
    const nameRef = db.doc(`usernames/${username}`);
    const [u, n] = await Promise.all([tx.get(userRef), tx.get(nameRef)]);
    need(!u.exists, "already-exists", "Account already set up.");
    need(!n.exists, "already-exists", "That username is already taken.");
    tx.set(nameRef, { uid });
    tx.set(userRef, {
      username, phone, sex,
      role: "user",
      status: "pending", // becomes "active" after the $1 is confirmed
      createdAt: FieldValue.serverTimestamp(),
      termsAcceptedAt: FieldValue.serverTimestamp(),
    });
  });
  return { ok: true };
});

exports.submitActivation = onCall(opts, async (req) => {
  need(req.auth, "unauthenticated", "Please sign in.");
  const u = await getUser(req.auth.uid);
  need(u.status === "pending", "failed-precondition", "Account is already active.");
  const txnId = String(req.data.txnId || "").trim().slice(0, 40);
  need(txnId.length >= 4, "invalid-argument", "Enter the Ecocash transaction ID.");
  await db.doc(`users/${u.id}`).update({
    activationTxn: txnId,
    activationRejected: FieldValue.delete(),
    activationSubmittedAt: FieldValue.serverTimestamp(),
  });
  await notifyAdmins(
    "Activation payment to check",
    `@${u.username} (${u.phone}) paid $1. Txn ${txnId}. Reference ${u.username.toUpperCase()}.`
  );
  return { ok: true };
});

exports.adminActivateUser = onCall(opts, async (req) => {
  await adminUser(req);
  const target = await getUser(String(req.data.uid));
  await db.doc(`users/${target.id}`).update({
    status: "active",
    activatedAt: FieldValue.serverTimestamp(),
  });
  await notify(target.id, "Welcome to Mverechena", "Your account is active. Enjoy!");
  return { ok: true };
});

exports.adminRejectActivation = onCall(opts, async (req) => {
  await adminUser(req);
  const target = await getUser(String(req.data.uid));
  await db.doc(`users/${target.id}`).update({
    activationTxn: FieldValue.delete(),
    activationRejected: true,
  });
  await notify(target.id, "Payment not found", "We could not match your $1 payment. Please check the transaction ID.");
  return { ok: true };
});

// --------------------------------------------------------------------- bidding

exports.placeBid = onCall(opts, async (req) => {
  const me = await activeUser(req);
  need(me.sex === "male", "permission-denied", "Only men can place bids.");
  const { postId, type } = req.data;
  const amount = r2(Number(req.data.amount));
  need(type === "short" || type === "full", "invalid-argument", "Choose short or full time.");
  need(Number.isFinite(amount) && amount >= MIN_BID && amount <= 5000, "invalid-argument",
    `Minimum bid is ${money(MIN_BID)}.`);

  const post = await db.doc(`posts/${postId}`).get();
  need(post.exists && post.data().approved === true, "not-found", "That post is not available.");
  const femaleUid = post.data().ownerUid;
  const female = await getUser(femaleUid);
  need(female.status === "active", "failed-precondition", "She is not available right now.");

  // one open bid per man per woman per type
  const mine = await db.collection("bids")
    .where("maleUid", "==", me.id).where("femaleUid", "==", femaleUid).get();
  const open = ["pending", "accepted", "escrow_submitted", "escrow_confirmed", "details_shared"];
  need(
    !mine.docs.some((d) => d.data().type === type && open.includes(d.data().status)),
    "already-exists", "You already have an open bid with her for that. Cancel it first."
  );

  const min = type === "short" ? female.shortMin : female.fullMin;
  const status = typeof min === "number" && amount < min ? "auto_rejected" : "pending";
  const fee = feeFor(amount);

  const ref = db.collection("bids").doc();
  const batch = db.batch();
  batch.set(ref, {
    postId, femaleUid, femaleName: female.username,
    maleUid: me.id, maleName: me.username,
    type, amount, fee, payout: r2(amount - fee),
    status, keywordAttempts: 0,
    createdAt: FieldValue.serverTimestamp(),
  });
  batch.set(db.doc(`bids_admin/${ref.id}`), {
    malePhone: me.phone, femalePhone: female.phone,
  });
  batch.update(post.ref, { bidCount: FieldValue.increment(1) });
  await batch.commit();

  if (status === "pending") {
    await notify(femaleUid, "New bid for you",
      `A ${type === "short" ? "short time" : "full time"} bid of ${money(amount)} is waiting.`, { bidId: ref.id });
  }
  return { status, bidId: ref.id };
});

exports.respondBid = onCall(opts, async (req) => {
  const me = await activeUser(req);
  const bid = await getBid(req.data.bidId);
  need(bid.femaleUid === me.id, "permission-denied", "Not your bid.");
  need(bid.status === "pending", "failed-precondition", "This bid is no longer pending.");
  if (req.data.accept === true) {
    await bid.ref.update({
      status: "accepted",
      acceptedAt: FieldValue.serverTimestamp(),
      escrowDeadline: Timestamp.fromMillis(Date.now() + ESCROW_WINDOW_HOURS * 3600 * 1000),
    });
    await notify(bid.maleUid, "She accepted!",
      `@${me.username} accepted your ${money(bid.amount)} bid. Pay into escrow within ${ESCROW_WINDOW_HOURS}h to lock the date.`,
      { bidId: bid.id });
  } else {
    await bid.ref.update({ status: "rejected" });
    await notify(bid.maleUid, "Bid declined", `@${me.username} declined your bid.`, { bidId: bid.id });
  }
  return { ok: true };
});

exports.cancelBid = onCall(opts, async (req) => {
  const me = await activeUser(req);
  const bid = await getBid(req.data.bidId);
  need(bid.maleUid === me.id, "permission-denied", "Not your bid.");
  need(["pending", "accepted"].includes(bid.status), "failed-precondition",
    "This bid can no longer be cancelled here. Use 'Report a problem' if something is wrong.");
  await bid.ref.update({ status: "cancelled" });
  if (bid.status === "accepted") {
    await notify(bid.femaleUid, "Bid cancelled", `@${me.username} cancelled the accepted bid.`, { bidId: bid.id });
  }
  return { ok: true };
});

// ---------------------------------------------------------------------- escrow

exports.submitEscrowTxn = onCall(opts, async (req) => {
  const me = await activeUser(req);
  const bid = await getBid(req.data.bidId);
  need(bid.maleUid === me.id, "permission-denied", "Not your bid.");
  need(bid.status === "accepted", "failed-precondition", "This bid is not waiting for payment.");
  const txnId = String(req.data.txnId || "").trim().slice(0, 40);
  need(txnId.length >= 4, "invalid-argument", "Enter the Ecocash transaction ID.");
  await bid.ref.update({
    status: "escrow_submitted",
    escrowTxn: txnId,
    escrowRejected: FieldValue.delete(),
    escrowSubmittedAt: FieldValue.serverTimestamp(),
  });
  await notifyAdmins("Escrow payment to confirm",
    `@${me.username} paid ${money(bid.amount)}. Ref ${code(bid.id)}, txn ${txnId}.`, { bidId: bid.id });
  return { ok: true };
});

exports.adminConfirmEscrow = onCall(opts, async (req) => {
  await adminUser(req);
  const bid = await getBid(req.data.bidId);
  need(bid.status === "escrow_submitted", "failed-precondition", "Nothing to confirm on this bid.");
  const keyword = makeKeyword();
  const batch = db.batch();
  batch.update(bid.ref, { status: "escrow_confirmed", escrowConfirmedAt: FieldValue.serverTimestamp() });
  batch.set(db.doc(`bids_private/${bid.id}`), { femaleUid: bid.femaleUid, keyword });
  await batch.commit();
  await notify(bid.femaleUid, "Confirmed - funds in escrow",
    "His payment is safe in escrow. Send the time, place and your phone number to get your keyword.", { bidId: bid.id });
  await notify(bid.maleUid, "Escrow confirmed",
    "Your funds are safe. You will get her time, place and phone number shortly.", { bidId: bid.id });
  return { ok: true };
});

exports.adminRejectEscrow = onCall(opts, async (req) => {
  await adminUser(req);
  const bid = await getBid(req.data.bidId);
  need(bid.status === "escrow_submitted", "failed-precondition", "Nothing to reject on this bid.");
  await bid.ref.update({
    status: "accepted",
    escrowTxn: FieldValue.delete(),
    escrowRejected: true,
  });
  await notify(bid.maleUid, "Payment not found",
    `We could not find your payment for ${code(bid.id)}. Check the transaction ID and try again.`, { bidId: bid.id });
  return { ok: true };
});

exports.submitDetails = onCall(opts, async (req) => {
  const me = await activeUser(req);
  const bid = await getBid(req.data.bidId);
  need(bid.femaleUid === me.id, "permission-denied", "Not your bid.");
  need(bid.status === "escrow_confirmed", "failed-precondition", "Escrow is not confirmed yet.");
  const when = new Date(String(req.data.dateTime));
  need(!isNaN(when.getTime()) && when.getTime() > Date.now(), "invalid-argument", "Pick a time in the future.");
  const location = String(req.data.location || "").trim().slice(0, 200);
  const phone = String(req.data.phone || "").trim().slice(0, 20);
  need(location.length >= 3, "invalid-argument", "Enter a meeting place.");
  need(phone.length >= 7, "invalid-argument", "Enter your phone number.");

  const batch = db.batch();
  batch.set(db.doc(`bids/${bid.id}/details/info`), {
    dateTime: Timestamp.fromDate(when), location, phone,
  });
  batch.update(bid.ref, { status: "details_shared", detailsAt: FieldValue.serverTimestamp() });
  await batch.commit();
  await notify(bid.maleUid, "Your date details are ready",
    `@${me.username} sent the time, place and phone number. Open My bids to see them.`, { bidId: bid.id });
  return { ok: true };
});

exports.submitKeyword = onCall(opts, async (req) => {
  const me = await activeUser(req);
  const result = await db.runTransaction(async (tx) => {
    const ref = db.doc(`bids/${req.data.bidId}`);
    const snap = await tx.get(ref);
    need(snap.exists, "not-found", "Bid not found.");
    const bid = snap.data();
    need(bid.maleUid === me.id, "permission-denied", "Not your bid.");
    need(bid.status === "details_shared", "failed-precondition", "This date is not ready for a keyword.");
    const attempts = bid.keywordAttempts || 0;
    need(attempts < MAX_KEYWORD_ATTEMPTS, "resource-exhausted",
      "Too many wrong attempts. Please contact Mverechena support.");
    const priv = await tx.get(db.doc(`bids_private/${snap.id}`));
    need(priv.exists, "internal", "Keyword missing. Contact support.");
    if (norm(req.data.keyword) === norm(priv.data().keyword)) {
      tx.update(ref, { status: "completed", completedAt: FieldValue.serverTimestamp() });
      return { ok: true, bid: { id: snap.id, ...bid } };
    }
    tx.update(ref, { keywordAttempts: attempts + 1 });
    return { ok: false, attemptsLeft: MAX_KEYWORD_ATTEMPTS - attempts - 1 };
  });

  if (result.ok) {
    const b = result.bid;
    await notifyAdmins("Keyword received - pay her",
      `@${b.maleName} entered the keyword for ${code(b.id)}. Pay @${b.femaleName} ${money(b.payout)} (fee ${money(b.fee)}).`,
      { bidId: b.id });
    await notify(b.femaleUid, "Keyword received",
      `Your payout of ${money(b.payout)} is being sent to your Ecocash.`, { bidId: b.id });
    return { ok: true };
  }
  return { ok: false, attemptsLeft: result.attemptsLeft };
});

exports.adminMarkPaid = onCall(opts, async (req) => {
  await adminUser(req);
  const bid = await getBid(req.data.bidId);
  need(bid.status === "completed", "failed-precondition", "This bid is not waiting for payout.");
  await bid.ref.update({
    status: "paid",
    payoutTxn: String(req.data.payoutTxn || "").slice(0, 40),
    paidAt: FieldValue.serverTimestamp(),
  });
  await notify(bid.femaleUid, "You have been paid",
    `${money(bid.payout)} was sent to your Ecocash for ${code(bid.id)}.`, { bidId: bid.id });
  return { ok: true };
});

// -------------------------------------------------------------------- disputes

exports.reportProblem = onCall(opts, async (req) => {
  const me = await activeUser(req);
  const bid = await getBid(req.data.bidId);
  need([bid.maleUid, bid.femaleUid].includes(me.id), "permission-denied", "Not your bid.");
  need(["escrow_confirmed", "details_shared", "completed"].includes(bid.status),
    "failed-precondition", "A problem can only be reported once funds are in escrow.");
  const reason = String(req.data.reason || "").trim().slice(0, 500);
  need(reason.length >= 3, "invalid-argument", "Tell us briefly what happened.");
  const batch = db.batch();
  batch.update(bid.ref, { status: "disputed" });
  batch.set(db.doc(`bids_admin/${bid.id}`), {
    disputedBy: `@${me.username}`, disputeReason: reason, prevStatus: bid.status,
    disputedAt: FieldValue.serverTimestamp(),
  }, { merge: true });
  await batch.commit();
  await notifyAdmins("Dispute reported", `${code(bid.id)}: ${reason}`, { bidId: bid.id });
  return { ok: true };
});

exports.adminResolveDispute = onCall(opts, async (req) => {
  await adminUser(req);
  const bid = await getBid(req.data.bidId);
  need(bid.status === "disputed", "failed-precondition", "This bid is not disputed.");
  if (req.data.outcome === "refund") {
    await bid.ref.update({ status: "refunded" });
    await notify(bid.maleUid, "Refund approved", `Your ${money(bid.amount)} for ${code(bid.id)} will be refunded.`);
    await notify(bid.femaleUid, "Dispute resolved", `${code(bid.id)} was resolved with a refund to the bidder.`);
  } else {
    await bid.ref.update({ status: "completed", completedAt: FieldValue.serverTimestamp() });
    await notify(bid.femaleUid, "Dispute resolved", `${code(bid.id)} was resolved in your favour. Payout is on its way.`);
    await notify(bid.maleUid, "Dispute resolved", `${code(bid.id)} was resolved. The payment goes to her.`);
  }
  return { ok: true };
});

// ----------------------------------------------------------------- moderation

exports.adminModeratePost = onCall(opts, async (req) => {
  await adminUser(req);
  const ref = db.doc(`posts/${req.data.postId}`);
  const snap = await ref.get();
  need(snap.exists, "not-found", "Post not found.");
  if (req.data.action === "approve") {
    await ref.update({ approved: true, approvedAt: FieldValue.serverTimestamp() });
    await notify(snap.data().ownerUid, "Your post is live", "It is now on the touchline.");
  } else {
    const path = snap.data().storagePath;
    await ref.delete();
    if (path) {
      try { await admin.storage().bucket().file(path).delete(); } catch (e) { /* already gone */ }
    }
    await notify(snap.data().ownerUid, "Post removed", "Your upload did not meet our rules and was removed.");
  }
  return { ok: true };
});

// -------------------------------------------------------------------- triggers

/** Keeps the like counter on a post in sync. */
exports.onLikeWrite = onDocumentWritten(
  { document: "posts/{postId}/likes/{uid}", region: REGION },
  async (event) => {
    const before = event.data.before.exists;
    const after = event.data.after.exists;
    if (before === after) return;
    await db.doc(`posts/${event.params.postId}`).update({
      likeCount: FieldValue.increment(after ? 1 : -1),
    });
  }
);

/** Hourly: expire unpaid accepted bids and stale pending bids. */
exports.expireStale = onSchedule({ schedule: "every 60 minutes", region: REGION }, async () => {
  const now = Date.now();
  const accepted = await db.collection("bids").where("status", "==", "accepted").get();
  for (const d of accepted.docs) {
    const dl = d.data().escrowDeadline;
    if (dl && dl.toMillis() < now) {
      await d.ref.update({ status: "expired" });
      await notify(d.data().maleUid, "Bid expired", "You did not pay into escrow in time, so the bid expired.");
      await notify(d.data().femaleUid, "Bid expired", "He did not pay into escrow in time.");
    }
  }
  const pending = await db.collection("bids").where("status", "==", "pending").get();
  for (const d of pending.docs) {
    const created = d.data().createdAt;
    if (created && created.toMillis() < now - PENDING_BID_DAYS * 86400 * 1000) {
      await d.ref.update({ status: "expired" });
    }
  }
});
